float c = 10.5;
int a = 3;
