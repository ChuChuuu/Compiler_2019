void main(){
	int a;
	print(a);
	float b=10;
	print(b);
	b/=2;
	return;
}
