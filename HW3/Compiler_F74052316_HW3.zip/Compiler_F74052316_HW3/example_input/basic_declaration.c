int a = 6;
int b;
string x = "GGS";
bool t;
void main() {
    int d;
    d = a + 6;
    print(d);
	print(x);
	float aa = 1;
	int bb =+3+aa--;
	print(aa);
	print(bb);
	return;
}

