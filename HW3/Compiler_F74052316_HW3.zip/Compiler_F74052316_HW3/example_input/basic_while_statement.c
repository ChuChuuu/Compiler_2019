void main(){
    int a = 1;
    while (a < 6){
		print(a);
        a++;
	}
	//
	print("-----------");
	int c = 1;
	int d = 0;
	int e = 0;
	while(c<5){
		print(c);
		d = 0;
		e = 0;
		while(d < 3){
			print(d);
			d++;
		}
		while(e < 2){
			print(e);
			e++;
		}
		c++;
	}
    return;
}

