int a(int b);
int a(float b){
	return 1;
}
void main(){
	print("HELLO");
	return;
}
