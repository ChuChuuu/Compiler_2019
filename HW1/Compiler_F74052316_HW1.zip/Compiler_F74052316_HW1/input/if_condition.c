if (x > a) {
    x = a;
    print(x);
} else {
    a = x;
    print(a);
}
